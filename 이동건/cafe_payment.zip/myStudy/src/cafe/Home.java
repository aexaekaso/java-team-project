package cafe;

import java.util.Scanner;

public class Home {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		boolean start = true;
		while(start) {
			System.out.println("========홈========");
			System.out.println("1.결제테스트");
			System.out.println("키를 입력하세요");
			int sel = sc.nextInt();
			if(sel ==1){
				Payment.paymentHome();
			}
		}
		sc.close();
	}

}
