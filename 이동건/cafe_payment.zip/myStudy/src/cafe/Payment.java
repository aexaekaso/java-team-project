package cafe;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Payment {
	static Scanner sc = new Scanner(System.in);
	private static ResultSet rs;
	static Connection con = null;
	static int c = 0;
	
	public Payment() {}
	
	public static void paymentHome() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost/cafedb";
			con = DriverManager.getConnection(url, "3jo", "1234");
			String sql = "SELECT customer_couponcheck, customer_coupon FROM customers where customer_id=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "asd"); //아이디 선택
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				c = rs.getInt("customer_coupon");
				System.out.println("======결제======");
				System.out.println("orderCart 내역");
				System.out.println("       총 금액");
				System.out.println("----------------");
				System.out.println("현재 가지고 있는 쿠폰 수는 "+c+"개");
//				System.out.println("현재 금액에서 사용할 수 있는 쿠폰 수는 "+c+"개");
				System.out.println("1. 일반 결제");
				System.out.println("2. 혼합 결제");
			}
			int sel = sc.nextInt();
			if(sel==1) {
				paymentNomal();
			}
			else if(sel==2) {
				paymentCoupon();
			}
			rs.close();
			pstmt.close();
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
        }catch (SQLException e) {
        	e.printStackTrace();
        }
	}
	
	public static void paymentNomal() {
		int order = 5000; //주문금액 테스트
		System.out.println("주문 하신 총 금액 : "+order);
		System.out.println("결제하실 금액을 입력하세요");
		while(order!=0) {
			int pay = sc.nextInt();
			if(order==pay || order==0) {
				System.out.println("결제 완료 되었습니다.\n");
				paymentAddCoupon();
				System.out.println("영수증 출력중(내역추가해야함)\n\n\n");
				break;
			}
			else if(order<pay) {
				System.out.println("주문 금액보다 결제금액이 큽니다\n다시입력하세요");
				continue;
			}
			else if(order>pay) {
				System.out.println(pay+"원 결제 되었습니다.\n남은 금액("+(order-pay)+")을 입력하세요.");
				order -= pay;
				continue;
			}
		}
	}
	
	public static void paymentCoupon() throws SQLException {
		int order = 5000; //주문금액 테스트
		int discount = 3000; //쿠폰 할인가격 테스트
		String sql = "SELECT customer_coupon FROM customers where customer_id=?";
		String sql2 = null;
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, "asd");
		rs = pstmt.executeQuery();
		
		System.out.println("주문 하신 총 금액 : "+order);
		while(rs.next()) {
			c = rs.getInt("customer_coupon");
			System.out.println("보유한 쿠폰의 개수는 "+c+"개 입니다.\n사용할 쿠폰 수를 입력하세요.");
		}
		while(order!=0) {
			int c_sel = sc.nextInt();
			if(c_sel<=0) {
				System.out.println("일반결제를 해주세요");
				break;
			}
			else if(c>=c_sel) {
				System.out.println((c_sel*discount)+"원 차감되었습니다.");
				if(order<(c_sel*discount)) {
					sql2 = "UPDATE customers set customer_coupon = customer_coupon-? where customer_id=?";
					PreparedStatement pstmt2 = con.prepareStatement(sql2);
					pstmt2.setLong(1, c_sel);
					pstmt2.setString(2, "asd"); //아이디 선택
					pstmt2.executeUpdate();
					System.out.println("결제 완료 되었습니다.\n");
					paymentAddCoupon();
					System.out.println("영수증 출력중(내역추가해야함)\n\n\n");
					break;
				}
				System.out.println("결제하실 남은 금액은 "+(order-(c_sel*discount))+"원 입니다.");
				order -= (c_sel*discount);
				
				System.out.println("결제하실 금액을 입력하세요");
				int pay = sc.nextInt();
				if(order==pay || order<=0) {
					sql2 = "UPDATE customers set customer_coupon = customer_coupon-? where customer_id=?";
					PreparedStatement pstmt2 = con.prepareStatement(sql2);
					pstmt2.setLong(1, c_sel);
					pstmt2.setString(2, "asd"); //아이디 선택
					pstmt2.executeUpdate();
					System.out.println("결제 완료 되었습니다.\n");
					paymentAddCoupon();
					System.out.println("영수증 출력중(내역추가해야함)\n\n\n");
					pstmt2.close();
					break;
				}
				else if(order<pay) {
					System.out.println("주문 금액보다 결제금액이 큽니다\n다시입력하세요");
					continue;
				}
				else if(order>pay) {
					System.out.println(pay+"원 결제 되었습니다.\n남은 금액("+(order-pay)+")을 입력하세요.");
					order -= pay;
					continue;
				}
			}
			else if(c<c_sel) {
				System.out.println("보유하신 쿠폰보다 더 입력하셨습니다.\n다시입력하세요");
				continue;
			}
		}
		rs.close();
		pstmt.close();
	}
	public static void paymentAddCoupon() {
		try {
			String sql = "SELECT customer_couponcheck FROM customers where customer_id=?";
			String sql2 = null;
			String sql3 = null;
			String sql4 = "SELECT customer_couponcheck FROM customers where customer_id=?";
			int count = 0;
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "asd"); //아이디 선택
			rs = pstmt.executeQuery();
			
			while(rs.next()) { //쿠폰 적립 수 확인
				int check = rs.getInt("customer_couponcheck");
				System.out.println("이전 스탬프 개수 : "+check+"\n");
			}
			sql2 = "UPDATE customers set customer_couponcheck = customer_couponcheck+1 where customer_id=?";
			PreparedStatement pstmt2 = con.prepareStatement(sql2);
			pstmt2.setString(1, "asd"); //아이디 선택
			System.out.println("스탬프 1개가 추가 되었습니다.\n");
			pstmt2.executeUpdate();
			PreparedStatement pstmt4 = con.prepareStatement(sql4);
			pstmt4.setString(1, "asd"); //아이디 선택
			rs = pstmt4.executeQuery();
			while(rs.next()) { //쿠폰 적립 수 확인
				int check = rs.getInt("customer_couponcheck");
				System.out.println("현재 스탬프 개수 : "+(check)+"\n");
				count = check;
			}
			if(count == 10){
				sql3 = "UPDATE customers set customer_couponcheck=customer_couponcheck-10, customer_coupon=customer_coupon+1 where customer_id=?";
				PreparedStatement pstmt3 = con.prepareStatement(sql3);
				pstmt3.setString(1, "asd"); //아이디 선택
				System.out.println("스탬프가 10개 적립되어 쿠폰 1개로 변경되었습니다.");
				pstmt3.executeUpdate();
				pstmt3.close();
			}
			pstmt2.close();
			pstmt.close();
			con.close();
			rs.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
